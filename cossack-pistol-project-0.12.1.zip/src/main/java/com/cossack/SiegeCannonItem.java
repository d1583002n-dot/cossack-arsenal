package com.cossack;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;

/** Right-click a block: the big siege cannon builds itself there, block by block. */
public class SiegeCannonItem extends Item {
    public SiegeCannonItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        if (!(context.getWorld() instanceof ServerWorld world)) {
            return ActionResult.SUCCESS;
        }
        PlayerEntity player = context.getPlayer();
        BlockPos pos = context.getBlockPos().offset(context.getSide());
        float yaw = player != null ? player.getYaw() : 0f;
        SiegeBuild.start(world, pos, yaw);
        if (player == null || !player.isCreative()) {
            context.getStack().decrement(1);
        }
        if (player instanceof ServerPlayerEntity sp) {
            sp.sendMessage(Text.translatable("msg.cossack.siege_building"), true);
        }
        return ActionResult.SUCCESS;
    }
}
