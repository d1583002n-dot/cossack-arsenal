package com.cossack;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;

/** The cannon item: right-click a block to place a cannon there. */
public class CannonItem extends Item {
    public CannonItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        if (!(context.getWorld() instanceof ServerWorld world)) {
            return ActionResult.SUCCESS;
        }
        PlayerEntity player = context.getPlayer();
        BlockPos pos = context.getBlockPos().offset(context.getSide());
        float yaw = player != null ? player.getYaw() : 0f;
        CannonLogic.place(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, yaw);
        ItemStack stack = context.getStack();
        if (player == null || !player.isCreative()) {
            stack.decrement(1);
        }
        return ActionResult.SUCCESS;
    }
}
