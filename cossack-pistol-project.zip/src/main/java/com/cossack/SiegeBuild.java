package com.cossack;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * The big siege cannon: it builds itself out of real blocks when placed (a few blocks per tick).
 * When it is finished, an invisible armor stand is spawned at the barrel; it is used like the other cannons:
 *   RMB on the cannon blocks = load / aim,   LMB = fire,   Sneak + LMB = dismantle (you get the item back).
 */
public final class SiegeBuild {
    public static final String TAG = "cossack_siege";
    private static final String BASE_TAG = "csb|";
    private static final int PER_TICK = 14;      // blocks placed per tick
    private static final int PIVOT_LZ = 8;       // barrel pivot along the cannon (where the stand is)
    private static final int FORWARD = 5;        // the structure starts this far in front of the player's target

    private static final class Job {
        final ServerWorld world;
        final BlockPos base;
        final int yaw;
        final List<BlockPos> pos = new ArrayList<>();
        final List<BlockState> states = new ArrayList<>();
        int index = 0;
        Job(ServerWorld world, BlockPos base, int yaw) {
            this.world = world;
            this.base = base;
            this.yaw = yaw;
        }
    }

    private static final List<Job> JOBS = new ArrayList<>();
    private static final Set<Long> KEYS = new HashSet<>();

    static {
        for (String line : SiegeData.BLOCKS) {
            String[] p = line.split(",");
            KEYS.add(key(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])));
        }
    }

    private SiegeBuild() {}

    private static long key(int lx, int ly, int lz) {
        return ((lx + 64L) << 40) | ((ly + 64L) << 20) | (lz + 64L);
    }

    /** {forward x, forward z, right x, right z} for a yaw that is a multiple of 90. */
    private static int[] frame(int yaw) {
        switch (((yaw % 360) + 360) % 360) {
            case 90:  return new int[]{-1, 0, 0, -1};
            case 180: return new int[]{0, -1, 1, 0};
            case 270: return new int[]{1, 0, 0, 1};
            default:  return new int[]{0, 1, -1, 0};
        }
    }

    private static int snapYaw(float yaw) {
        int y = Math.round(yaw / 90f) * 90;
        return ((y % 360) + 360) % 360;
    }

    private static BlockPos worldPos(BlockPos base, int[] fr, int lx, int ly, int lz) {
        return new BlockPos(base.getX() + lx * fr[2] + lz * fr[0], base.getY() + ly, base.getZ() + lx * fr[3] + lz * fr[1]);
    }

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(SiegeBuild::tick);

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || !(world instanceof ServerWorld sw) || !(player instanceof ServerPlayerEntity sp)) {
                return ActionResult.PASS;
            }
            ArmorStandEntity stand = standFor(sw, hit.getBlockPos());
            if (stand == null) return ActionResult.PASS;
            CannonLogic.use(sw, sp, stand);
            return ActionResult.SUCCESS;
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!(world instanceof ServerWorld sw) || !(player instanceof ServerPlayerEntity sp)) {
                return ActionResult.PASS;
            }
            ArmorStandEntity stand = standFor(sw, pos);
            if (stand == null) return ActionResult.PASS;
            if (hand == Hand.MAIN_HAND) {
                if (sp.isSneaking()) dismantle(sw, sp, stand);
                else CannonLogic.fire(sw, sp, stand);
            }
            return ActionResult.FAIL;
        });
    }

    /** Start building a siege cannon in front of pos, facing where the player looks. */
    public static void start(ServerWorld world, BlockPos pos, float playerYaw) {
        int yaw = snapYaw(playerYaw);
        int[] fr = frame(yaw);
        BlockPos base = pos.add(fr[0] * FORWARD, 0, fr[1] * FORWARD);
        Job job = new Job(world, base, yaw);
        for (String line : SiegeData.BLOCKS) {
            String[] p = line.split(",");
            Block block = Registries.BLOCK.get(Identifier.of(p[3]));
            job.pos.add(worldPos(base, fr, Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])));
            job.states.add(block.getDefaultState());
        }
        JOBS.add(job);
    }

    private static void tick(ServerWorld world) {
        Iterator<Job> it = JOBS.iterator();
        while (it.hasNext()) {
            Job j = it.next();
            if (j.world != world) continue;
            int placed = 0;
            BlockPos last = null;
            while (placed < PER_TICK && j.index < j.pos.size()) {
                BlockPos p = j.pos.get(j.index);
                BlockState s = j.states.get(j.index);
                j.index++;
                BlockState cur = world.getBlockState(p);
                if (cur.isAir() || cur.isReplaceable()) {
                    world.setBlockState(p, s);
                    last = p;
                    placed++;
                }
            }
            if (last != null) {
                world.playSound(null, last, SoundEvents.BLOCK_WOOD_PLACE, SoundCategory.BLOCKS, 0.7f, 0.8f + 0.4f * world.random.nextFloat());
                world.spawnParticles(ParticleTypes.CLOUD, last.getX() + 0.5, last.getY() + 0.8, last.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.01);
            }
            if (j.index >= j.pos.size()) {
                finish(world, j);
                it.remove();
            }
        }
    }

    private static void finish(ServerWorld world, Job j) {
        int[] fr = frame(j.yaw);
        double cx = j.base.getX() + 0.5 + PIVOT_LZ * fr[0];
        double cz = j.base.getZ() + 0.5 + PIVOT_LZ * fr[1];
        double y = j.base.getY() + CannonLogic.STAND_Y_OFFSET;
        ArmorStandEntity stand = new ArmorStandEntity(world, cx, y, cz);
        stand.refreshPositionAndAngles(cx, y, cz, j.yaw, 0f);
        stand.setBodyYaw(j.yaw);
        stand.setInvisible(true);
        stand.setNoGravity(true);
        stand.setInvulnerable(true);
        stand.addCommandTag(CannonLogic.TAG);
        stand.addCommandTag(TAG);
        stand.addCommandTag(BASE_TAG + j.base.getX() + "|" + j.base.getY() + "|" + j.base.getZ() + "|" + j.yaw);
        world.spawnEntity(stand);
        world.playSound(null, j.base, SoundEvents.BLOCK_ANVIL_PLACE, SoundCategory.BLOCKS, 1.0f, 0.6f);
    }

    /** {baseX, baseY, baseZ, yaw} stored on the stand, or null. */
    private static int[] parse(ArmorStandEntity stand) {
        for (String t : stand.getCommandTags()) {
            if (t.startsWith(BASE_TAG)) {
                String[] p = t.substring(BASE_TAG.length()).split("\\|");
                try {
                    return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])};
                } catch (NumberFormatException ignored) {
                    return null;
                }
            }
        }
        return null;
    }

    /** The siege cannon whose blocks contain this position, or null. */
    private static ArmorStandEntity standFor(ServerWorld w, BlockPos pos) {
        List<ArmorStandEntity> stands = w.getEntitiesByClass(ArmorStandEntity.class, new Box(pos).expand(24),
                e -> e.getCommandTags().contains(TAG));
        for (ArmorStandEntity s : stands) {
            int[] b = parse(s);
            if (b == null) continue;
            int[] fr = frame(b[3]);
            int dx = pos.getX() - b[0];
            int dz = pos.getZ() - b[2];
            int dy = pos.getY() - b[1];
            int lz = dx * fr[0] + dz * fr[1];
            int lx = dx * fr[2] + dz * fr[3];
            if (KEYS.contains(key(lx, dy, lz))) return s;
        }
        return null;
    }

    /** Removes the blocks (only those that are still the original ones) and gives the item back. */
    public static void dismantle(ServerWorld world, ServerPlayerEntity player, ArmorStandEntity stand) {
        int[] b = parse(stand);
        if (b != null) {
            BlockPos base = new BlockPos(b[0], b[1], b[2]);
            int[] fr = frame(b[3]);
            for (String line : SiegeData.BLOCKS) {
                String[] p = line.split(",");
                Block block = Registries.BLOCK.get(Identifier.of(p[3]));
                BlockPos wp = worldPos(base, fr, Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]));
                if (world.getBlockState(wp).isOf(block)) {
                    world.setBlockState(wp, Blocks.AIR.getDefaultState());
                }
            }
        }
        if (!player.isCreative()) {
            player.getInventory().offerOrDrop(new ItemStack(CossackMod.SIEGE_CANNON));
        }
        stand.discard();
    }
}
