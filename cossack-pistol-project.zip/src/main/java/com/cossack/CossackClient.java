package com.cossack;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class CossackClient implements ClientModInitializer {
    private static KeyBinding reloadKey;
    private static KeyBinding modeKey;
    private boolean wasAttackDown = false;

    private static boolean holdingPistol(PlayerEntity p) {
        return p.getMainHandStack().getItem() instanceof GunItem;
    }

    @Override
    public void onInitializeClient() {
        reloadKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cossack.reload", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.cossack"));

        modeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cossack.mode", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.cossack"));

        // LMB must not break blocks or hit mobs while holding the pistol
        AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) ->
                holdingPistol(player) ? ActionResult.FAIL : ActionResult.PASS);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                holdingPistol(player) ? ActionResult.FAIL : ActionResult.PASS);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                wasAttackDown = false;
                return;
            }
            boolean down = client.options.attackKey.isPressed();
            boolean active = holdingPistol(client.player) && client.currentScreen == null;
            if (active && down && !wasAttackDown) {
                ClientPlayNetworking.send(new ActionPayload(ActionPayload.FIRE));
            }
            while (reloadKey.wasPressed()) {
                if (active) ClientPlayNetworking.send(new ActionPayload(ActionPayload.RELOAD));
            }
            while (modeKey.wasPressed()) {
                if (active) ClientPlayNetworking.send(new ActionPayload(ActionPayload.MODE));
            }
            wasAttackDown = down;
        });
    }
}
