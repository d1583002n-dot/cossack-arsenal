package com.cossack;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class CossackMod implements ModInitializer {
    public static final String MOD_ID = "cossack";
    public static Item PISTOL;

    @Override
    public void onInitialize() {
        Identifier id = Identifier.of(MOD_ID, "cossack_pistol");
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        PISTOL = Registry.register(Registries.ITEM, key,
                new CossackPistolItem(new Item.Settings().registryKey(key).maxCount(1)));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(PISTOL));

        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            ItemStack stack = player.getMainHandStack();
            if (stack.getItem() instanceof CossackPistolItem pistol) {
                if (payload.action() == ActionPayload.FIRE) {
                    pistol.fire(player.getServerWorld(), player, stack);
                } else if (payload.action() == ActionPayload.RELOAD) {
                    pistol.reload(player.getServerWorld(), player, stack);
                }
            }
        });
    }
}
