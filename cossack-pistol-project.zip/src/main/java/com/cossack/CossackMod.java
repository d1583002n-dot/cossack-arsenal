package com.cossack;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class CossackMod implements ModInitializer {
    public static final String MOD_ID = "cossack";
    public static Item PISTOL;
    public static Item CARBINE_1793;
    public static Item FUZEE_1709;

    private static Item registerGun(String name, GunItem.Stats stats) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        return Registry.register(Registries.ITEM, key,
                new GunItem(new Item.Settings().registryKey(key).maxCount(1), stats));
    }

    @Override
    public void onInitialize() {
        // damage, range, spread hip, spread aim (deg), reload ticks (per charge), cooldown ticks (per bullet),
        // sound pitch, capacity (charges), max fire mode (0 = single only, 2 = single/double/volley)
        PISTOL = registerGun("cossack_pistol", new GunItem.Stats(12f, 60, 4.0, 0.4, 60, 20, 0.6f, 1, 0));
        CARBINE_1793 = registerGun("carbine_1793", new GunItem.Stats(18f, 120, 6.0, 0.15, 100, 30, 0.5f, 1, 0));
        FUZEE_1709 = registerGun("fuzee_1709", new GunItem.Stats(10f, 90, 5.0, 0.8, 40, 15, 0.45f, 4, 2));

        // Own creative tab: "Cossack Arsenal"
        ItemGroup tab = FabricItemGroup.builder()
                .icon(() -> new ItemStack(PISTOL))
                .displayName(Text.translatable("itemGroup.cossack.arsenal"))
                .entries((context, entries) -> {
                    entries.add(PISTOL);
                    entries.add(CARBINE_1793);
                    entries.add(FUZEE_1709);
                })
                .build();
        Registry.register(Registries.ITEM_GROUP, Identifier.of(MOD_ID, "arsenal"), tab);

        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            ItemStack stack = player.getMainHandStack();
            if (stack.getItem() instanceof GunItem gun) {
                if (payload.action() == ActionPayload.FIRE) {
                    gun.fire(player.getServerWorld(), player, stack);
                } else if (payload.action() == ActionPayload.RELOAD) {
                    gun.reload(player.getServerWorld(), player, stack);
                } else if (payload.action() == ActionPayload.MODE) {
                    gun.cycleMode(player, stack);
                }
            }
        });
    }
}
