package com.cossack;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class CossackMod implements ModInitializer {
    public static final String MOD_ID = "cossack";
    public static Item PISTOL;
    public static Item CARBINE_1793;

    private static Item registerGun(String name, GunItem.Stats stats) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        return Registry.register(Registries.ITEM, key,
                new GunItem(new Item.Settings().registryKey(key).maxCount(1), stats));
    }

    @Override
    public void onInitialize() {
        // damage, range, spread hip, spread aim (degrees), reload ticks, cooldown ticks, sound pitch
        PISTOL = registerGun("cossack_pistol", new GunItem.Stats(12f, 60, 4.0, 0.4, 60, 20, 0.6f));
        CARBINE_1793 = registerGun("carbine_1793", new GunItem.Stats(18f, 120, 6.0, 0.15, 100, 30, 0.5f));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(PISTOL);
            entries.add(CARBINE_1793);
        });

        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            ItemStack stack = player.getMainHandStack();
            if (stack.getItem() instanceof GunItem pistol) {
                if (payload.action() == ActionPayload.FIRE) {
                    pistol.fire(player.getServerWorld(), player, stack);
                } else if (payload.action() == ActionPayload.RELOAD) {
                    pistol.reload(player.getServerWorld(), player, stack);
                }
            }
        });
    }
}
