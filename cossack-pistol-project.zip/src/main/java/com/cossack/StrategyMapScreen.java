package com.cossack;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Повноекранне стратегічне меню «Козацька держава».
 *
 * Картинка (1536x1024) розрізана на частини, які прив'язуються до країв екрана:
 * верхня панель ресурсів — до верху, нижня панель — до низу, бокові блоки — до лівого й правого країв.
 * Середина екрана заповнюється картою (масштабується з обрізанням), порожнечі в панелях — смугами дерева.
 * Блюру немає, курсор — власний.
 */
public class StrategyMapScreen extends Screen {
    private static final Identifier MAP = Identifier.of("cossack", "textures/gui/strategy_map.png");
    private static final Identifier FILL_TOP = Identifier.of("cossack", "textures/gui/bar_top_fill.png");
    private static final Identifier FILL_BOT = Identifier.of("cossack", "textures/gui/bar_bot_fill.png");
    private static final Identifier CURSOR = Identifier.of("cossack", "textures/gui/cursor.png");

    private static final int IMG_W = 1536, IMG_H = 1024;

    // частини картинки: {x0, y0, x1, y1}
    private static final int TOP_L = 0, TOP_M = 1, TOP_R = 2, LEFT_P = 3, RIGHT_P = 4, BOT_L = 5, BOT_M = 6, BOT_R = 7;
    private static final int[][] PIECES = {
        {0, 0, 372, 84}, {372, 0, 1127, 84}, {1127, 0, 1536, 84},
        {4, 102, 266, 798}, {1218, 92, 1532, 434},
        {0, 846, 440, 1024}, {440, 846, 1167, 1024}, {1167, 846, 1536, 1024}
    };
    private static final int TOP_H = 84, BOT_Y = 846;
    // чиста ділянка карти без панелей: {x0, y0, x1, y1}
    private static final int[] CORE = {268, 86, 1216, 844};

    // клікабельні зони: {частина, x0, y0, x1, y1} у координатах картинки
    private static final int[][] ZONES = {
        {BOT_M, 480, 862, 596, 986},   // Армія
        {BOT_M, 606, 862, 712, 986},   // Міста
        {BOT_M, 722, 862, 820, 986},   // Дипломатія
        {BOT_M, 830, 862, 930, 986},   // Економіка
        {BOT_M, 937, 862, 1035, 986},  // Карта
        {BOT_M, 1042, 862, 1142, 986}, // Технології
        {TOP_R, 1312, 10, 1364, 64},   // Журнал
        {TOP_R, 1368, 10, 1422, 64},   // Повідомлення
        {TOP_R, 1424, 10, 1476, 64},   // Налаштування
        {TOP_R, 1480, 10, 1530, 64}    // Пауза — закриває меню
    };
    private static final String[] NAMES = {
        "Армія", "Міста", "Дипломатія", "Економіка", "Карта", "Технології",
        "Журнал", "Повідомлення", "Налаштування", "Закрити"
    };

    private String status = null;
    private long statusUntil = 0;

    // Власний курсор. У режимі «захоплення» (Android/PojavLauncher) лаунчер ховає свою стрілку
    // і передає рух пальця як відносний, тож позицію курсора ведемо самі.
    private boolean grab = false;
    private double cx, cy;
    private double lastX, lastY;
    private boolean haveLast = false;

    /** config/cossack.properties: grab_cursor = auto | true | false */
    private static boolean wantGrab() {
        String mode = "auto";
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("cossack.properties");
            Properties pr = new Properties();
            if (Files.exists(f)) {
                try (InputStream in = Files.newInputStream(f)) { pr.load(in); }
            }
            if (!pr.containsKey("grab_cursor")) {
                pr.setProperty("grab_cursor", "auto");
                try (OutputStream out = Files.newOutputStream(f)) {
                    pr.store(out, "grab_cursor: auto (only on PojavLauncher) | true | false");
                }
            }
            mode = pr.getProperty("grab_cursor", "auto").trim().toLowerCase();
        } catch (Exception ignored) { }
        if (mode.equals("true")) return true;
        if (mode.equals("false")) return false;
        return System.getenv("POJAV_RENDERER") != null || System.getenv("POJAV_NATIVEDIR") != null;
    }

    public StrategyMapScreen() {
        super(Text.literal("Козацька держава"));
    }

    private float k() {
        return Math.min((float) this.width / IMG_W, (float) this.height / IMG_H);
    }

    private int pieceX(int p, float k) {
        int[] r = PIECES[p];
        float w = (r[2] - r[0]) * k;
        switch (p) {
            case TOP_L: case BOT_L: return 0;
            case TOP_M: case BOT_M: return Math.round(this.width / 2f - w / 2f);
            case TOP_R: case BOT_R: return Math.round(this.width - w);
            case LEFT_P: return Math.round(r[0] * k);
            default: return Math.round(this.width - (IMG_W - r[0]) * k);
        }
    }

    private int pieceY(int p, float k) {
        int[] r = PIECES[p];
        if (p <= TOP_R) return 0;
        if (p == LEFT_P || p == RIGHT_P) return Math.round(r[1] * k);
        return Math.round(this.height - (IMG_H - r[1]) * k);
    }

    private void blit(DrawContext ctx, Identifier tex, int dx, int dy, int dw, int dh,
                      float u, float v, int rw, int rh, int tw, int th) {
        ctx.drawTexture(RenderLayer::getGuiTextured, tex, dx, dy, u, v, dw, dh, rw, rh, tw, th, 0xFFFFFFFF);
    }

    /** Прямокутник зони на екрані: {x0, y0, x1, y1}. */
    private int[] zoneRect(int i, float k) {
        int[] z = ZONES[i];
        int[] src = PIECES[z[0]];
        int px = pieceX(z[0], k), py = pieceY(z[0], k);
        return new int[] {
            px + Math.round((z[1] - src[0]) * k), py + Math.round((z[2] - src[1]) * k),
            px + Math.round((z[3] - src[0]) * k), py + Math.round((z[4] - src[1]) * k)
        };
    }

    @Override
    protected void init() {
        super.init();
        grab = wantGrab();
        cx = this.width / 2.0;
        cy = this.height / 2.0;
        haveLast = false;
        if (this.client != null) {
            GLFW.glfwSetInputMode(this.client.getWindow().getHandle(), GLFW.GLFW_CURSOR,
                grab ? GLFW.GLFW_CURSOR_DISABLED : GLFW.GLFW_CURSOR_HIDDEN);
        }
    }

    @Override
    public void mouseMoved(double x, double y) {
        if (grab) {
            if (haveLast) {
                double dx = x - lastX, dy = y - lastY;
                if (Math.abs(dx) < 300 && Math.abs(dy) < 300) { // ігноруємо стрибки при вході в режим
                    cx += dx;
                    cy += dy;
                }
            }
            lastX = x;
            lastY = y;
            haveLast = true;
        } else {
            cx = x;
            cy = y;
        }
        cx = Math.max(0, Math.min(this.width - 1, cx));
        cy = Math.max(0, Math.min(this.height - 1, cy));
        super.mouseMoved(x, y);
    }

    @Override
    public void removed() {
        if (this.client != null) {
            GLFW.glfwSetInputMode(this.client.getWindow().getHandle(), GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
        }
        super.removed();
    }

    @Override
    public void render(DrawContext ctx, int mouseXIgnored, int mouseYIgnored, float delta) {
        int mouseX = (int) cx, mouseY = (int) cy;
        // super.render() не викликаємо: саме він розмиває фон.
        ctx.fill(0, 0, this.width, this.height, 0xFF000000);

        float k = k();
        int topH = Math.round(TOP_H * k);
        int botY = Math.round(this.height - (IMG_H - BOT_Y) * k);

        // 1) карта на весь простір між панелями (cover: масштаб з обрізанням по краях)
        int mapY = topH, mapH = botY - topH;
        int coreW = CORE[2] - CORE[0], coreH = CORE[3] - CORE[1];
        float c = Math.max((float) this.width / coreW, (float) mapH / coreH);
        float sw = this.width / c, sh = mapH / c;
        float u = CORE[0] + (coreW - sw) / 2f, v = CORE[1] + (coreH - sh) / 2f;
        blit(ctx, MAP, 0, mapY, this.width, mapH, u, v, Math.round(sw), Math.round(sh), IMG_W, IMG_H);

        // 2) смуги дерева під верхню й нижню панелі на всю ширину
        blit(ctx, FILL_TOP, 0, 0, this.width, topH, 0f, 0f, 8, 84, 8, 84);
        blit(ctx, FILL_BOT, 0, botY, this.width, this.height - botY, 0f, 0f, 8, 178, 8, 178);

        // 3) частини інтерфейсу в рідному масштабі, прив'язані до країв
        for (int p = 0; p < PIECES.length; p++) {
            int[] r = PIECES[p];
            int w = r[2] - r[0], h = r[3] - r[1];
            blit(ctx, MAP, pieceX(p, k), pieceY(p, k), Math.round(w * k), Math.round(h * k),
                 r[0], r[1], w, h, IMG_W, IMG_H);
        }

        // 4) підсвічування кнопки під курсором
        for (int i = 0; i < ZONES.length; i++) {
            int[] z = zoneRect(i, k);
            if (mouseX >= z[0] && mouseX < z[2] && mouseY >= z[1] && mouseY < z[3]) {
                ctx.fill(z[0], z[1], z[2], z[3], 0x35FFE2A0);
            }
        }

        if (status != null && System.currentTimeMillis() < statusUntil) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, status, this.width / 2, topH + 6, 0xFFF3E2B8);
        }

        // 5) власний курсор
        blit(ctx, CURSOR, mouseX, mouseY, 14, 14, 0f, 0f, 32, 32, 32, 32);
    }

    @Override
    public boolean mouseClicked(double mxIgnored, double myIgnored, int button) {
        double mx = cx, my = cy;
        if (button == 0) {
            float k = k();
            for (int i = 0; i < ZONES.length; i++) {
                int[] z = zoneRect(i, k);
                if (mx >= z[0] && mx < z[2] && my >= z[1] && my < z[3]) {
                    if (i == ZONES.length - 1) {
                        this.close();
                    } else {
                        status = NAMES[i] + ": скоро буде!";
                        statusUntil = System.currentTimeMillis() + 2000;
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
