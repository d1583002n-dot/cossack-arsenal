package com.cossack;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Повноекранне стратегічне меню «Козацька держава».
 * Малюнок відображається у пропорціях 3:2 по центру екрана, без блюру.
 * Клікабельні зони задані в координатах самої картинки (1536x1024).
 */
public class StrategyMapScreen extends Screen {
    private static final Identifier TEXTURE = Identifier.of("cossack", "textures/gui/strategy_map.png");
    private static final int IMG_W = 1536;
    private static final int IMG_H = 1024;

    /** {x0, y0, x1, y1} у координатах картинки. */
    private static final int[][] ZONES = {
        {480, 862, 596, 986},   // Армія
        {606, 862, 712, 986},   // Міста
        {722, 862, 820, 986},   // Дипломатія
        {830, 862, 930, 986},   // Економіка
        {937, 862, 1035, 986},  // Карта
        {1042, 862, 1142, 986}, // Технології
        {1312, 10, 1364, 64},   // Журнал
        {1368, 10, 1422, 64},   // Повідомлення
        {1424, 10, 1476, 64},   // Налаштування
        {1480, 10, 1530, 64}    // Пауза — закриває меню
    };
    private static final String[] NAMES = {
        "Армія", "Міста", "Дипломатія", "Економіка", "Карта", "Технології",
        "Журнал", "Повідомлення", "Налаштування", "Закрити"
    };

    private String status = null;
    private long statusUntil = 0;

    public StrategyMapScreen() {
        super(Text.literal("Козацька держава"));
    }

    private float scale() {
        return Math.min((float) this.width / IMG_W, (float) this.height / IMG_H);
    }

    private int originX(int w) { return (this.width - w) / 2; }
    private int originY(int h) { return (this.height - h) / 2; }

    private boolean inZone(int i, double mx, double my) {
        float s = scale();
        int w = Math.round(IMG_W * s), h = Math.round(IMG_H * s);
        double ix = (mx - originX(w)) / s;
        double iy = (my - originY(h)) / s;
        int[] z = ZONES[i];
        return ix >= z[0] && ix < z[2] && iy >= z[1] && iy < z[3];
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // super.render() не викликаємо: саме він розмиває фон.
        ctx.fill(0, 0, this.width, this.height, 0xFF000000);

        float s = scale();
        int w = Math.round(IMG_W * s), h = Math.round(IMG_H * s);
        int ox = originX(w), oy = originY(h);

        ctx.drawTexture(RenderLayer::getGuiTextured, TEXTURE, ox, oy, 0.0F, 0.0F, w, h, IMG_W, IMG_H, IMG_W, IMG_H, 0xFFFFFFFF);

        for (int i = 0; i < ZONES.length; i++) {
            if (inZone(i, mouseX, mouseY)) {
                int[] z = ZONES[i];
                ctx.fill(ox + Math.round(z[0] * s), oy + Math.round(z[1] * s),
                         ox + Math.round(z[2] * s), oy + Math.round(z[3] * s), 0x35FFE2A0);
            }
        }

        if (status != null && System.currentTimeMillis() < statusUntil) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, status, this.width / 2, Math.max(4, oy + 8), 0xFFF3E2B8);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = 0; i < ZONES.length; i++) {
                if (inZone(i, mx, my)) {
                    if (i == ZONES.length - 1) {
                        this.close();
                    } else {
                        status = NAMES[i] + ": скоро буде!";
                        statusUntil = System.currentTimeMillis() + 2000;
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
