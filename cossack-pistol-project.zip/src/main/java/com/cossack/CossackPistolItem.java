package com.cossack;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Optional;

/**
 * Cossack flintlock pistol.
 * RMB (hold) = aim, LMB = fire (packet from client), R = reload (packet from client).
 */
public class CossackPistolItem extends Item {
    private static final String LOADED = "loaded";
    private static final double RANGE = 60.0;
    private static final float DAMAGE = 12.0f;
    private static final int RELOAD_TICKS = 60; // 3 seconds

    public CossackPistolItem(Settings settings) {
        super(settings);
    }

    public static boolean isLoaded(ItemStack stack) {
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        return c != null && c.copyNbt().getBoolean(LOADED);
    }

    private static void setLoaded(ItemStack stack, boolean value) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> nbt.putBoolean(LOADED, value));
    }

    // Holding RMB = aiming (slows the player down like using an item)
    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        player.setCurrentHand(hand);
        return ActionResult.CONSUME;
    }

    @Override
    public int getMaxUseTime(ItemStack stack, LivingEntity user) {
        return 72000;
    }

    private static void sound(ServerWorld w, PlayerEntity p, SoundEvent s, float vol, float pitch) {
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, vol, pitch);
    }

    public void reload(ServerWorld world, ServerPlayerEntity p, ItemStack stack) {
        if (isLoaded(stack) || p.getItemCooldownManager().isCoolingDown(stack)) return;
        boolean creative = p.isCreative();
        if (!creative) {
            if (p.getInventory().count(Items.GUNPOWDER) < 1 || p.getInventory().count(Items.IRON_NUGGET) < 1) {
                p.sendMessage(net.minecraft.text.Text.literal("Need: gunpowder + iron nugget"), true);
                return;
            }
            p.getInventory().remove(s -> s.isOf(Items.GUNPOWDER), 1, p.getInventory());
            p.getInventory().remove(s -> s.isOf(Items.IRON_NUGGET), 1, p.getInventory());
        }
        setLoaded(stack, true);
        p.getItemCooldownManager().set(stack, RELOAD_TICKS);
        sound(world, p, SoundEvents.BLOCK_SAND_PLACE, 1.0f, 0.8f);
        sound(world, p, SoundEvents.ITEM_FLINTANDSTEEL_USE, 0.6f, 1.2f);
    }

    public void fire(ServerWorld world, ServerPlayerEntity p, ItemStack stack) {
        if (p.getItemCooldownManager().isCoolingDown(stack)) return;
        if (!isLoaded(stack)) {
            sound(world, p, SoundEvents.BLOCK_DISPENSER_FAIL, 1.0f, 1.6f); // misfire click
            p.getItemCooldownManager().set(stack, 10);
            return;
        }
        setLoaded(stack, false);

        boolean aiming = p.isUsingItem() && p.getActiveItem().isOf(this);
        double spread = aiming ? 0.4 : 4.0; // degrees
        float yaw = p.getYaw() + (float) (p.getRandom().nextGaussian() * spread);
        float pitch = p.getPitch() + (float) (p.getRandom().nextGaussian() * spread);

        Vec3d eye = p.getEyePos();
        Vec3d dir = Vec3d.fromPolar(pitch, yaw);
        Vec3d end = eye.add(dir.multiply(RANGE));

        HitResult blockHit = world.raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        double maxDist = blockHit.getType() == HitResult.Type.MISS ? RANGE : blockHit.getPos().distanceTo(eye);
        end = eye.add(dir.multiply(maxDist));

        Box area = p.getBoundingBox().stretch(dir.multiply(maxDist)).expand(1.0);
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : world.getOtherEntities(p, area, en -> en instanceof LivingEntity && en.isAlive() && !en.isSpectator())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(eye, end);
            if (hit.isPresent()) {
                double d = hit.get().distanceTo(eye);
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        if (best != null) {
            best.damage(world, world.getDamageSources().playerAttack(p), DAMAGE);
        }

        Vec3d muzzle = eye.add(dir.multiply(0.9));
        world.spawnParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 4, 0.05, 0.05, 0.05, 0.02);
        world.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 14, 0.12, 0.12, 0.12, 0.03);
        sound(world, p, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 2.5f, 0.6f);
        sound(world, p, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.5f, 1.8f);
        p.getItemCooldownManager().set(stack, 20);
    }
}
