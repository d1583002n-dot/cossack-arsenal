package com.cossack;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Placeable cannons. A cannon is an invisible armor stand that wears the cannon item on its head
 * (so no custom entity / renderer is needed). Everything is handled on the server.
 *
 *  RMB            : load (2 gunpowder + 1 iron ingot). When already loaded: aim - the cannon turns to where
 *                   you look and raises the barrel by 5 degrees per click (shows the flight path).
 *  Sneak + RMB    : same, but lowers the barrel by 5 degrees.
 *  LMB            : fire.
 *  Sneak + LMB    : pick the cannon up again.
 */
public final class CannonLogic {
    public static final String TAG = "cossack_cannon";
    private static final String LOADED = "cc_loaded";
    private static final String ELEV = "cc_el_";

    // ---- tuning ----
    /** Stand is spawned this far below the floor, because the head item floats above the stand. Adjust if the cannon floats/sinks. */
    public static final double STAND_Y_OFFSET = -1.22;

    /** Per-cannon-type tuning. The cannon type is decided by the item the armor stand wears on its head. */
    private record Kind(double barrelHeight,   // barrel height above the floor
                        double barrelLength,   // muzzle distance from the cannon centre
                        double speed,          // cannonball speed, blocks per tick
                        float power,           // explosion power (TNT = 4.0)
                        int loadTicks,         // loading time
                        int fireTicks,         // pause after a shot
                        int gunpowder,         // ammo: gunpowder
                        int ironIngots,        // ammo: iron ingots
                        String needAmmoKey,
                        int defElev,           // default barrel elevation (degrees)
                        int minElev,           // elevation limits; min == max means a fixed barrel angle
                        int maxElev) {}

    private static final Kind CANNON_KIND = new Kind(0.75, 1.6, 3.0, 4.0f, 400, 40, 2, 1, "msg.cossack.cannon_need_ammo", 10, 0, 45);
    // Falconet: small and light - quicker to load, faster ball, weaker explosion
    private static final Kind FALCONET_KIND = new Kind(0.9, 1.8, 3.6, 2.2f, 240, 25, 1, 1, "msg.cossack.falconet_need_ammo", 10, 0, 45);
    // Field gun: medium blast, high speed. Ship gun: long iron barrel on a truck carriage.
    private static final Kind FIELD_KIND = new Kind(0.9, 1.8, 4.2, 3.0f, 300, 30, 2, 1, "msg.cossack.cannon_need_ammo", 8, 0, 40);
    private static final Kind SHIP_KIND = new Kind(0.8, 1.8, 3.6, 3.2f, 320, 35, 2, 1, "msg.cossack.cannon_need_ammo", 6, 0, 30);
    // Howitzer (fixed 45 deg barrel): explosive shell, big blast. Mortar (fixed 65 deg): lobbed shot, siege blast.
    private static final Kind HOWITZER_KIND = new Kind(0.79, 1.22, 2.8, 6.0f, 500, 60, 3, 2, "msg.cossack.heavy_need_ammo", 45, 45, 45);
    private static final Kind MORTAR_KIND = new Kind(0.65, 0.95, 2.2, 5.0f, 450, 50, 3, 2, "msg.cossack.heavy_need_ammo", 65, 65, 65);
    // Big self-building siege cannon (barrel centre 7.5 blocks above the base, muzzle 9.5 blocks from the pivot)
    private static final Kind SIEGE_KIND = new Kind(7.5, 9.5, 3.4, 8.0f, 600, 80, 4, 2, "msg.cossack.siege_need_ammo", 15, 0, 55);

    private static Kind kindOf(ArmorStandEntity stand) {
        if (stand.getCommandTags().contains(SiegeBuild.TAG)) return SIEGE_KIND;
        Item head = stand.getEquippedStack(EquipmentSlot.HEAD).getItem();
        if (head == CossackMod.FALCONET) return FALCONET_KIND;
        if (head == CossackMod.FIELD_CANNON) return FIELD_KIND;
        if (head == CossackMod.SHIP_CANNON) return SHIP_KIND;
        if (head == CossackMod.HOWITZER) return HOWITZER_KIND;
        if (head == CossackMod.MORTAR) return MORTAR_KIND;
        return CANNON_KIND;
    }
    private static final int DEFAULT_ELEV = 10, MAX_ELEV = 45, STEP = 5;

    private static final Map<UUID, Long> BUSY = new HashMap<>();
    private static final List<Ball> BALLS = new ArrayList<>();

    private static final class Ball {
        final SnowballEntity entity;
        final ServerWorld world;
        final float power;
        Vec3d pos;
        Vec3d vel;
        int age;
        Ball(SnowballEntity entity, ServerWorld world, float power) {
            this.entity = entity;
            this.world = world;
            this.power = power;
            this.pos = entity.getPos();
            this.vel = entity.getVelocity();
        }
    }

    private CannonLogic() {}

    public static void init() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!isCannon(entity)) return ActionResult.PASS;
            if (!(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) return ActionResult.PASS;
            if (hand == Hand.MAIN_HAND) use(sw, sp, (ArmorStandEntity) entity);
            return ActionResult.SUCCESS;
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!isCannon(entity)) return ActionResult.PASS;
            if (!(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) return ActionResult.PASS;
            if (hand == Hand.MAIN_HAND) {
                if (sp.isSneaking()) pickUp(sw, sp, (ArmorStandEntity) entity);
                else fire(sw, sp, (ArmorStandEntity) entity);
            }
            return ActionResult.SUCCESS;
        });
        ServerTickEvents.END_WORLD_TICK.register(CannonLogic::tickBalls);
    }

    private static boolean isCannon(Entity e) {
        return e instanceof ArmorStandEntity s && s.getCommandTags().contains(TAG);
    }

    // ---------------------------------------------------------------- placing

    public static void place(ServerWorld world, double x, double y, double z, float yaw, Item item) {
        ArmorStandEntity stand = new ArmorStandEntity(world, x, y + STAND_Y_OFFSET, z);
        stand.refreshPositionAndAngles(x, y + STAND_Y_OFFSET, z, yaw, 0f);
        stand.setBodyYaw(yaw);
        stand.setInvisible(true);
        stand.setNoGravity(true);
        stand.setInvulnerable(true);
        stand.equipStack(EquipmentSlot.HEAD, new ItemStack(item));
        stand.addCommandTag(TAG);
        world.spawnEntity(stand);
        sound(world, x, y, z, SoundEvents.BLOCK_ANVIL_PLACE, 0.8f, 0.7f);
    }

    private static void pickUp(ServerWorld w, ServerPlayerEntity p, ArmorStandEntity stand) {
        if (stand.getCommandTags().contains(SiegeBuild.TAG)) {
            SiegeBuild.dismantle(w, p, stand);
            return;
        }
        if (!p.isCreative()) p.getInventory().offerOrDrop(new ItemStack(stand.getEquippedStack(EquipmentSlot.HEAD).getItem()));
        BUSY.remove(stand.getUuid());
        stand.discard();
    }

    // ---------------------------------------------------------------- state helpers

    private static int elevation(ArmorStandEntity stand) {
        for (String t : stand.getCommandTags()) {
            if (t.startsWith(ELEV)) {
                try { return Integer.parseInt(t.substring(ELEV.length())); } catch (NumberFormatException ignored) {}
            }
        }
        return kindOf(stand).defElev();
    }

    private static void setElevation(ArmorStandEntity stand, int el) {
        for (String t : new ArrayList<>(stand.getCommandTags())) {
            if (t.startsWith(ELEV)) stand.removeCommandTag(t);
        }
        stand.addCommandTag(ELEV + el);
    }

    private static Vec3d direction(ArmorStandEntity stand) {
        return Vec3d.fromPolar(-elevation(stand), stand.getYaw());
    }

    private static Vec3d muzzle(ArmorStandEntity stand) {
        Vec3d dir = direction(stand);
        Kind k = kindOf(stand);
        return new Vec3d(stand.getX(), stand.getY() - STAND_Y_OFFSET + k.barrelHeight(), stand.getZ())
                .add(dir.multiply(k.barrelLength()));
    }

    // ---------------------------------------------------------------- actions

    static void use(ServerWorld w, ServerPlayerEntity p, ArmorStandEntity stand) {
        // turn the cannon to where the player looks
        float yaw = p.getYaw();
        stand.refreshPositionAndAngles(stand.getX(), stand.getY(), stand.getZ(), yaw, 0f);
        stand.setBodyYaw(yaw);

        Kind kind = kindOf(stand);
        long now = w.getTime();
        boolean loaded = stand.getCommandTags().contains(LOADED);
        if (!loaded) {
            if (BUSY.getOrDefault(stand.getUuid(), 0L) > now) {
                p.sendMessage(Text.translatable("msg.cossack.cannon_busy"), true);
                return;
            }
            if (!p.isCreative()) {
                if (p.getInventory().count(Items.GUNPOWDER) < kind.gunpowder() || p.getInventory().count(Items.IRON_INGOT) < kind.ironIngots()) {
                    p.sendMessage(Text.translatable(kind.needAmmoKey()), true);
                    return;
                }
                p.getInventory().remove(s -> s.isOf(Items.GUNPOWDER), kind.gunpowder(), p.getInventory());
                p.getInventory().remove(s -> s.isOf(Items.IRON_INGOT), kind.ironIngots(), p.getInventory());
            }
            stand.addCommandTag(LOADED);
            BUSY.put(stand.getUuid(), now + kind.loadTicks());
            sound(w, stand.getX(), stand.getY(), stand.getZ(), SoundEvents.BLOCK_SAND_PLACE, 1.0f, 0.6f);
            sound(w, stand.getX(), stand.getY(), stand.getZ(), SoundEvents.ITEM_FLINTANDSTEEL_USE, 0.8f, 1.0f);
            p.sendMessage(Text.translatable("msg.cossack.cannon_loading"), true);
            return;
        }
        int el = elevation(stand);
        if (kind.minElev() < kind.maxElev()) {
            el = p.isSneaking() ? el - STEP : el + STEP;
            if (el > kind.maxElev()) el = kind.minElev();
            if (el < kind.minElev()) el = kind.maxElev();
        } else {
            el = kind.defElev();   // fixed barrel angle
        }
        setElevation(stand, el);
        p.sendMessage(Text.translatable("msg.cossack.cannon_aim", el), true);
        preview(w, p, stand);
    }

    static void fire(ServerWorld w, ServerPlayerEntity p, ArmorStandEntity stand) {
        long now = w.getTime();
        if (BUSY.getOrDefault(stand.getUuid(), 0L) > now) {
            p.sendMessage(Text.translatable("msg.cossack.cannon_busy"), true);
            return;
        }
        if (!stand.getCommandTags().contains(LOADED)) {
            p.sendMessage(Text.translatable("msg.cossack.cannon_empty"), true);
            return;
        }
        Kind kind = kindOf(stand);
        stand.removeCommandTag(LOADED);
        BUSY.put(stand.getUuid(), now + kind.fireTicks());

        Vec3d dir = direction(stand);
        Vec3d m = muzzle(stand);
        SnowballEntity ball = new SnowballEntity(w, m.x, m.y, m.z, new ItemStack(Items.FIRE_CHARGE));
        ball.setVelocity(dir.multiply(kind.speed()));
        w.spawnEntity(ball);
        BALLS.add(new Ball(ball, w, kind.power()));

        w.spawnParticles(ParticleTypes.FLAME, m.x, m.y, m.z, 25, 0.15, 0.15, 0.15, 0.08);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, m.x, m.y, m.z, 20, 0.3, 0.3, 0.3, 0.05);
        w.spawnParticles(ParticleTypes.EXPLOSION, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        sound(w, m.x, m.y, m.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 3.0f, 0.7f);
        sound(w, m.x, m.y, m.z, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 3.0f, 0.4f);
    }

    // ---------------------------------------------------------------- flight path preview (only the aiming player sees it)

    private static void preview(ServerWorld w, ServerPlayerEntity p, ArmorStandEntity stand) {
        Vec3d pos = muzzle(stand);
        Vec3d vel = direction(stand).multiply(kindOf(stand).speed());
        for (int i = 0; i < 600; i++) {
            Vec3d next = pos.add(vel);
            HitResult hit = w.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (hit.getType() != HitResult.Type.MISS) {
                Vec3d h = hit.getPos();
                w.spawnParticles(p, ParticleTypes.FLAME, true, false, h.x, h.y, h.z, 12, 0.25, 0.25, 0.25, 0.02);
                break;
            }
            if (i % 3 == 0) {
                w.spawnParticles(p, ParticleTypes.END_ROD, true, false, next.x, next.y, next.z, 1, 0, 0, 0, 0);
            }
            pos = next;
            vel = vel.multiply(0.99).add(0, -0.03, 0);
            if (pos.y < w.getBottomY()) break;
        }
    }

    // ---------------------------------------------------------------- cannonballs in flight

    private static void tickBalls(ServerWorld world) {
        Iterator<Ball> it = BALLS.iterator();
        while (it.hasNext()) {
            Ball b = it.next();
            if (b.world != world) continue;
            b.age++;
            if (b.entity.isRemoved() || b.age > 600) {
                Vec3d at = impactPoint(b);
                if (!b.entity.isRemoved()) b.entity.discard();
                explode(world, at, b.power);
                it.remove();
                continue;
            }
            b.pos = b.entity.getPos();
            b.vel = b.entity.getVelocity();
            // visible smoke trail
            world.spawnParticles(ParticleTypes.LARGE_SMOKE, b.pos.x, b.pos.y, b.pos.z, 1, 0.02, 0.02, 0.02, 0.0);
            world.spawnParticles(ParticleTypes.FLAME, b.pos.x, b.pos.y, b.pos.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    /** The ball disappears one step before the real hit point, so look ahead along its last velocity. */
    private static Vec3d impactPoint(Ball b) {
        Vec3d from = b.pos;
        Vec3d to = from.add(b.vel);
        HitResult hit = b.world.raycast(new RaycastContext(from, to,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, b.entity));
        if (hit.getType() != HitResult.Type.MISS) return hit.getPos();
        return from.add(b.vel.multiply(0.5));
    }

    private static void explode(ServerWorld w, Vec3d at, float power) {
        w.createExplosion(null, at.x, at.y, at.z, power, World.ExplosionSourceType.TNT);
    }

    private static void sound(ServerWorld w, double x, double y, double z, SoundEvent s, float vol, float pitch) {
        w.playSound(null, x, y, z, s, SoundCategory.PLAYERS, vol, pitch);
    }
}
