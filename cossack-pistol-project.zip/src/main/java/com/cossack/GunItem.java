package com.cossack;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * One class for all flintlock guns. Each gun = different Stats.
 * RMB (hold) = aim, LMB = fire, reload key = load ONE charge, mode key = switch fire mode.
 * Modes: 0 = single, 1 = double (2 bullets per shot), 2 = volley (all loaded charges).
 */
public class GunItem extends Item {
    public record Stats(float damage, double range, double spreadHip, double spreadAim,
                        int reloadTicks, int fireCooldown, float soundPitch,
                        int capacity, int maxMode) {}

    private static final String LOADED = "loaded"; // old saves
    private static final String AMMO = "ammo";
    private static final String MODE = "mode";
    private final Stats stats;

    public GunItem(Settings settings, Stats stats) {
        super(settings);
        this.stats = stats;
    }

    private static NbtCompound data(ItemStack stack) {
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? new NbtCompound() : c.copyNbt();
    }

    public static int getAmmo(ItemStack stack) {
        NbtCompound n = data(stack);
        if (n.contains(AMMO)) return n.getInt(AMMO);
        return n.getBoolean(LOADED) ? 1 : 0;
    }

    private static void setAmmo(ItemStack stack, int v) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> {
            nbt.putInt(AMMO, v);
            nbt.remove(LOADED);
        });
    }

    public static int getMode(ItemStack stack) {
        return data(stack).getInt(MODE);
    }

    private static void setMode(ItemStack stack, int v) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> nbt.putInt(MODE, v));
    }

    private Text statusText(ItemStack stack) {
        int a = getAmmo(stack);
        Formatting color = a > 0 ? Formatting.GREEN : Formatting.RED;
        if (stats.capacity() == 1) {
            return Text.translatable(a > 0 ? "tooltip.cossack.loaded" : "tooltip.cossack.unloaded").formatted(color);
        }
        return Text.translatable("tooltip.cossack.charge", a, stats.capacity()).formatted(color);
    }

    private Text modeText(ItemStack stack) {
        int m = Math.min(getMode(stack), stats.maxMode());
        return Text.translatable("mode.cossack." + m);
    }

    @Override
    public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(statusText(stack));
        if (stats.maxMode() > 0) {
            tooltip.add(Text.translatable("tooltip.cossack.mode", modeText(stack)).formatted(Formatting.YELLOW));
        }
        tooltip.add(Text.translatable("tooltip.cossack.ammo").formatted(Formatting.GRAY));
    }

    // Holding RMB = aiming (slows the player down like using an item)
    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        player.setCurrentHand(hand);
        return ActionResult.CONSUME;
    }

    @Override
    public int getMaxUseTime(ItemStack stack, LivingEntity user) {
        return 72000;
    }

    private static void sound(ServerWorld w, PlayerEntity p, SoundEvent s, float vol, float pitch) {
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, vol, pitch);
    }

    public void cycleMode(ServerPlayerEntity p, ItemStack stack) {
        if (stats.maxMode() == 0) {
            p.sendMessage(Text.translatable("msg.cossack.one_mode"), true);
            return;
        }
        int next = (Math.min(getMode(stack), stats.maxMode()) + 1) % (stats.maxMode() + 1);
        setMode(stack, next);
        p.sendMessage(Text.translatable("tooltip.cossack.mode", modeText(stack)).formatted(Formatting.YELLOW), true);
    }

    // Loads ONE charge per press (powder + bullet), up to capacity
    public void reload(ServerWorld world, ServerPlayerEntity p, ItemStack stack) {
        if (p.getItemCooldownManager().isCoolingDown(stack)) return;
        int ammo = getAmmo(stack);
        if (ammo >= stats.capacity()) {
            p.sendMessage(Text.translatable("msg.cossack.full"), true);
            return;
        }
        if (!p.isCreative()) {
            if (p.getInventory().count(Items.GUNPOWDER) < 1 || p.getInventory().count(Items.IRON_NUGGET) < 1) {
                p.sendMessage(Text.translatable("msg.cossack.need_ammo"), true);
                return;
            }
            p.getInventory().remove(s -> s.isOf(Items.GUNPOWDER), 1, p.getInventory());
            p.getInventory().remove(s -> s.isOf(Items.IRON_NUGGET), 1, p.getInventory());
        }
        setAmmo(stack, ammo + 1);
        p.getItemCooldownManager().set(stack, stats.reloadTicks());
        sound(world, p, SoundEvents.BLOCK_SAND_PLACE, 1.0f, 0.8f);
        sound(world, p, SoundEvents.ITEM_FLINTANDSTEEL_USE, 0.6f, 1.2f);
        p.sendMessage(statusText(stack), true);
    }

    public void fire(ServerWorld world, ServerPlayerEntity p, ItemStack stack) {
        if (p.getItemCooldownManager().isCoolingDown(stack)) return;
        int ammo = getAmmo(stack);
        if (ammo <= 0) {
            sound(world, p, SoundEvents.BLOCK_DISPENSER_FAIL, 1.0f, 1.6f); // misfire click
            p.sendMessage(Text.translatable("msg.cossack.empty").formatted(Formatting.RED), true);
            p.getItemCooldownManager().set(stack, 10);
            return;
        }
        int mode = Math.min(getMode(stack), stats.maxMode());
        int bullets = mode == 0 ? 1 : (mode == 1 ? Math.min(2, ammo) : ammo);
        setAmmo(stack, ammo - bullets);

        boolean aiming = p.isUsingItem() && p.getActiveItem().isOf(this);
        double base = aiming ? stats.spreadAim() : stats.spreadHip();
        // several bullets = they scatter like buckshot: close = all hit, far = they fly apart
        double pellet = bullets > 1 ? (mode == 1 ? 2.0 : 3.5) * (aiming ? 0.6 : 1.0) : 0.0;
        double spread = base + pellet;

        // damage of all bullets is summed per target and applied ONCE
        // (otherwise Minecraft's hit immunity cancels the 2nd, 3rd... bullet)
        Map<Entity, Float> hits = new HashMap<>();
        for (int i = 0; i < bullets; i++) {
            shootBullet(world, p, spread, bullets > 1, hits);
        }
        for (Map.Entry<Entity, Float> en : hits.entrySet()) {
            en.getKey().damage(world, world.getDamageSources().playerAttack(p), en.getValue());
        }
        sound(world, p, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 2.5f, stats.soundPitch());
        sound(world, p, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.5f, 1.8f);
        p.getItemCooldownManager().set(stack, stats.fireCooldown() * bullets);
        p.sendMessage(statusText(stack), true);
    }

    private void shootBullet(ServerWorld world, ServerPlayerEntity p, double spread,
                              boolean multi, Map<Entity, Float> hits) {
        float yaw = p.getYaw() + (float) (p.getRandom().nextGaussian() * spread);
        float pitch = p.getPitch() + (float) (p.getRandom().nextGaussian() * spread);

        Vec3d eye = p.getEyePos();
        Vec3d dir = Vec3d.fromPolar(pitch, yaw);
        double range = stats.range();
        Vec3d end = eye.add(dir.multiply(range));

        HitResult blockHit = world.raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        double maxDist = blockHit.getType() == HitResult.Type.MISS ? range : blockHit.getPos().distanceTo(eye);
        end = eye.add(dir.multiply(maxDist));

        Box area = p.getBoundingBox().stretch(dir.multiply(maxDist)).expand(1.0);
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : world.getOtherEntities(p, area, en -> en instanceof LivingEntity && en.isAlive() && !en.isSpectator())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(eye, end);
            if (hit.isPresent()) {
                double d = hit.get().distanceTo(eye);
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        if (best != null) {
            float dmg = stats.damage();
            if (multi) {
                // far away multi-bullet shots lose power (down to 30%)
                dmg *= (float) Math.max(0.3, 1.0 - bestDist / 40.0);
            }
            hits.merge(best, dmg, Float::sum);
        }

        Vec3d muzzle = eye.add(dir.multiply(0.9));
        world.spawnParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 3, 0.05, 0.05, 0.05, 0.02);
        world.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 10, 0.12, 0.12, 0.12, 0.03);
    }
}
