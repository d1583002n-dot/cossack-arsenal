package com.cossack;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;
import java.util.Optional;

/**
 * One class for all flintlock guns. Each gun = different Stats.
 * RMB (hold) = aim, LMB = fire, reload key = reload.
 */
public class GunItem extends Item {
    public record Stats(float damage, double range, double spreadHip, double spreadAim,
                        int reloadTicks, int fireCooldown, float soundPitch) {}

    private static final String LOADED = "loaded";
    private final Stats stats;

    public GunItem(Settings settings, Stats stats) {
        super(settings);
        this.stats = stats;
    }

    public static boolean isLoaded(ItemStack stack) {
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        return c != null && c.copyNbt().getBoolean(LOADED);
    }

    private static void setLoaded(ItemStack stack, boolean value) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> nbt.putBoolean(LOADED, value));
    }

    @Override
    public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
        if (isLoaded(stack)) {
            tooltip.add(Text.translatable("tooltip.cossack.loaded").formatted(Formatting.GREEN));
        } else {
            tooltip.add(Text.translatable("tooltip.cossack.unloaded").formatted(Formatting.RED));
        }
        tooltip.add(Text.translatable("tooltip.cossack.ammo").formatted(Formatting.GRAY));
    }

    // Holding RMB = aiming (slows the player down like using an item)
    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        player.setCurrentHand(hand);
        return ActionResult.CONSUME;
    }

    @Override
    public int getMaxUseTime(ItemStack stack, LivingEntity user) {
        return 72000;
    }

    private static void sound(ServerWorld w, PlayerEntity p, SoundEvent s, float vol, float pitch) {
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, vol, pitch);
    }

    public void reload(ServerWorld world, ServerPlayerEntity p, ItemStack stack) {
        if (isLoaded(stack) || p.getItemCooldownManager().isCoolingDown(stack)) return;
        if (!p.isCreative()) {
            if (p.getInventory().count(Items.GUNPOWDER) < 1 || p.getInventory().count(Items.IRON_NUGGET) < 1) {
                p.sendMessage(Text.translatable("msg.cossack.need_ammo"), true);
                return;
            }
            p.getInventory().remove(s -> s.isOf(Items.GUNPOWDER), 1, p.getInventory());
            p.getInventory().remove(s -> s.isOf(Items.IRON_NUGGET), 1, p.getInventory());
        }
        setLoaded(stack, true);
        p.getItemCooldownManager().set(stack, stats.reloadTicks());
        sound(world, p, SoundEvents.BLOCK_SAND_PLACE, 1.0f, 0.8f);
        sound(world, p, SoundEvents.ITEM_FLINTANDSTEEL_USE, 0.6f, 1.2f);
        p.sendMessage(Text.translatable("tooltip.cossack.loaded").formatted(Formatting.GREEN), true);
    }

    public void fire(ServerWorld world, ServerPlayerEntity p, ItemStack stack) {
        if (p.getItemCooldownManager().isCoolingDown(stack)) return;
        if (!isLoaded(stack)) {
            sound(world, p, SoundEvents.BLOCK_DISPENSER_FAIL, 1.0f, 1.6f); // misfire click
            p.sendMessage(Text.translatable("msg.cossack.empty").formatted(Formatting.RED), true);
            p.getItemCooldownManager().set(stack, 10);
            return;
        }
        setLoaded(stack, false);

        boolean aiming = p.isUsingItem() && p.getActiveItem().isOf(this);
        double spread = aiming ? stats.spreadAim() : stats.spreadHip();
        float yaw = p.getYaw() + (float) (p.getRandom().nextGaussian() * spread);
        float pitch = p.getPitch() + (float) (p.getRandom().nextGaussian() * spread);

        Vec3d eye = p.getEyePos();
        Vec3d dir = Vec3d.fromPolar(pitch, yaw);
        double range = stats.range();
        Vec3d end = eye.add(dir.multiply(range));

        HitResult blockHit = world.raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        double maxDist = blockHit.getType() == HitResult.Type.MISS ? range : blockHit.getPos().distanceTo(eye);
        end = eye.add(dir.multiply(maxDist));

        Box area = p.getBoundingBox().stretch(dir.multiply(maxDist)).expand(1.0);
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : world.getOtherEntities(p, area, en -> en instanceof LivingEntity && en.isAlive() && !en.isSpectator())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(eye, end);
            if (hit.isPresent()) {
                double d = hit.get().distanceTo(eye);
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        if (best != null) {
            best.damage(world, world.getDamageSources().playerAttack(p), stats.damage());
        }

        Vec3d muzzle = eye.add(dir.multiply(0.9));
        world.spawnParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 4, 0.05, 0.05, 0.05, 0.02);
        world.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 14, 0.12, 0.12, 0.12, 0.03);
        sound(world, p, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 2.5f, stats.soundPitch());
        sound(world, p, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.5f, 1.8f);
        p.getItemCooldownManager().set(stack, stats.fireCooldown());
        p.sendMessage(Text.translatable("tooltip.cossack.unloaded").formatted(Formatting.RED), true);
    }
}
