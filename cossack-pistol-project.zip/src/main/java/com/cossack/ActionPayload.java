package com.cossack;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record ActionPayload(int action) implements CustomPayload {
    public static final int FIRE = 0;
    public static final int RELOAD = 1;

    public static final CustomPayload.Id<ActionPayload> ID =
            new CustomPayload.Id<>(Identifier.of(CossackMod.MOD_ID, "action"));
    public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, ActionPayload::action, ActionPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
